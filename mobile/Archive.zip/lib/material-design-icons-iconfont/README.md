# Material design icons

This repo is a fork of the original, created to make it easy to add dependency to in bower / npm
everything except the `iconfont` directory has been ommited (since it's irrelevant when you want to just reference the final product)

## Getting Started

using bower 
```
bower install material-design-icons-iconfont --save
```

using npm
```
npm install material-design-icons-iconfont --save
```

